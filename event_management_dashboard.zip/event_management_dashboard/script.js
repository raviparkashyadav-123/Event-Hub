const initialEvents = [
 {name:"AI Innovation Summit 2026",category:"Conference",date:"2026-10-28",time:"09:30",venue:"Grand Convention Center",attendees:420,capacity:500,status:"Upcoming",color:"purple",symbol:"✦"},
 {name:"Design Thinking Workshop",category:"Workshop",date:"2026-10-24",time:"11:00",venue:"Studio Hall, Block A",attendees:86,capacity:100,status:"Upcoming",color:"blue",symbol:"◇"},
 {name:"Tech Connect Networking",category:"Networking",date:"2026-10-22",time:"16:00",venue:"The Atrium",attendees:156,capacity:180,status:"Live",color:"green",symbol:"⌘"},
 {name:"Future of Data Conference",category:"Conference",date:"2026-11-05",time:"10:00",venue:"City Expo Center",attendees:310,capacity:400,status:"Upcoming",color:"orange",symbol:"▥"},
 {name:"Product Launch Meetup",category:"Networking",date:"2026-11-12",time:"14:30",venue:"Innovation Hub",attendees:0,capacity:150,status:"Draft",color:"purple",symbol:"↗"},
 {name:"Creative Coding Bootcamp",category:"Workshop",date:"2026-11-18",time:"09:00",venue:"Lab 03",attendees:64,capacity:80,status:"Upcoming",color:"blue",symbol:"⌘"}
];
let events = JSON.parse(localStorage.getItem("eventflow-events") || "null") || initialEvents;
let attendees = JSON.parse(localStorage.getItem("eventflow-attendees") || "null") || [
 {name:"Priya Sharma",email:"priya@example.com",event:"AI Innovation Summit 2026"},
 {name:"Arjun Singh",email:"arjun@example.com",event:"Design Thinking Workshop"},
 {name:"Neha Verma",email:"neha@example.com",event:"Tech Connect Networking"}
];
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fmtDate = d => { if(!d) return "Date TBD"; return new Date(d+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}); };
function save(){localStorage.setItem("eventflow-events",JSON.stringify(events));localStorage.setItem("eventflow-attendees",JSON.stringify(attendees));}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove("show"),2800);}
function renderEvents(filter=""){
 const body=$("#eventTable"); if(!body)return;
 const filtered=events.filter(e=>(e.name+" "+e.venue+" "+e.category+" "+e.status).toLowerCase().includes(filter.toLowerCase()));
 body.innerHTML=filtered.slice(0,8).map((e,i)=>`<tr><td><div class="event-cell"><div class="event-symbol ${e.color||"purple"}">${e.symbol||"✦"}</div><div><b>${escapeHtml(e.name)}</b><small>${escapeHtml(e.category)}</small></div></div></td><td>${fmtDate(e.date)}<br><small>${e.time||"10:00"}</small></td><td>${escapeHtml(e.venue)}</td><td>${Number(e.attendees||0).toLocaleString()} / ${Number(e.capacity||0).toLocaleString()}</td><td><span class="status ${e.status}">${e.status}</span></td><td><button class="row-menu" data-event-index="${events.indexOf(e)}" title="Event actions">⋯</button></td></tr>`).join("");
 if(!filtered.length) body.innerHTML='<tr><td colspan="6" class="empty-state">No matching events found.</td></tr>';
 $("#eventNavCount").textContent=events.length;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function openEventDialog(){ $("#eventForm").reset(); $("#eventDialog").showModal(); }
function openAttendeeDialog(){ $("#attendeeForm").reset(); $("#attendeeEvent").innerHTML=events.map(e=>`<option>${escapeHtml(e.name)}</option>`).join(""); $("#attendeeDialog").showModal(); }
$("#newEventBtn").addEventListener("click",openEventDialog); $("#quickEvent").addEventListener("click",openEventDialog);
$("#quickAttendee").addEventListener("click",openAttendeeDialog);
$("#eventForm").addEventListener("submit",e=>{
 e.preventDefault();
 const name=$("#eventName").value.trim(); if(!name)return;
 const colors=["purple","blue","green","orange"];
 events.unshift({name,category:$("#eventCategory").value,date:$("#eventDate").value,time:$("#eventTime").value,venue:$("#eventVenue").value.trim(),attendees:0,capacity:Number($("#eventCapacity").value),status:"Upcoming",color:colors[events.length%4],symbol:"✦"});
 save();renderEvents($("#globalSearch").value);$("#eventDialog").close();toast("Event created successfully!");
 $("#totalEvents").textContent=24+Math.max(0,events.length-initialEvents.length);
});
$("#attendeeForm").addEventListener("submit",e=>{
 e.preventDefault();attendees.push({name:$("#attendeeName").value.trim(),email:$("#attendeeEmail").value.trim(),event:$("#attendeeEvent").value});
 const event=events.find(x=>x.name===$("#attendeeEvent").value);if(event)event.attendees=(Number(event.attendees)||0)+1;
 save();renderEvents($("#globalSearch").value);$("#attendeeDialog").close();toast("Attendee added successfully!");
});
$("#globalSearch").addEventListener("input",e=>renderEvents(e.target.value));
document.addEventListener("click",e=>{
 const nav=e.target.closest("[data-page]");if(nav){e.preventDefault();showPage(nav.dataset.page);}
 const goto=e.target.closest("[data-goto]");if(goto)showPage(goto.dataset.goto);
 const menu=e.target.closest("[data-event-index]");if(menu){const i=Number(menu.dataset.eventIndex);if(confirm(`Delete "${events[i].name}" from this demo dashboard?`)){events.splice(i,1);save();renderEvents($("#globalSearch").value);toast("Event removed.");}}
});
function showPage(page){
 const labels={overview:"Overview",events:"Events",attendees:"Attendees",speakers:"Speakers",venues:"Venues",reports:"Reports",settings:"Settings"};
 $$(".nav-link[data-page]").forEach(a=>a.classList.toggle("active",a.dataset.page===page));
 $("#pageTitle").textContent=labels[page]||"Overview";
 $("#overviewPage").classList.toggle("hidden",page!=="overview");$("#genericPage").classList.toggle("hidden",page==="overview");
 $("#sidebar").classList.remove("open");
 if(page==="overview")return;
 $("#genericTitle").textContent=labels[page]||"Workspace";
 const descriptions={events:"Create, search and manage all your events.",attendees:"Keep track of registered participants.",speakers:"Manage speakers and session hosts.",venues:"Manage locations and venue availability.",reports:"Review event performance and export data.",settings:"Manage your workspace preferences."};
 $("#genericDescription").textContent=descriptions[page]||"Manage your workspace.";
 $("#genericAction").textContent=page==="attendees"?"＋ Add attendee":page==="events"?"＋ Create event":page==="reports"?"⇩ Export report":"＋ Add new";
 $("#genericAction").onclick=()=>{if(page==="attendees")openAttendeeDialog();else if(page==="events")openEventDialog();else if(page==="reports")exportCSV();else toast("Demo action: "+labels[page]+" form can be connected to a backend.");};
 renderGeneric(page);
}
function renderGeneric(page){
 const box=$("#genericContent");
 if(page==="events"){box.innerHTML=`<div class="table-wrap"><table><thead><tr><th>EVENT</th><th>DATE</th><th>VENUE</th><th>ATTENDEES</th><th>STATUS</th></tr></thead><tbody>${events.map(e=>`<tr><td><b>${escapeHtml(e.name)}</b><br><small>${escapeHtml(e.category)}</small></td><td>${fmtDate(e.date)}</td><td>${escapeHtml(e.venue)}</td><td>${e.attendees}/${e.capacity}</td><td><span class="status ${e.status}">${e.status}</span></td></tr>`).join("")}</tbody></table></div>`}
 else if(page==="attendees"){box.innerHTML=`<div class="table-wrap"><table><thead><tr><th>NAME</th><th>EMAIL</th><th>EVENT</th><th>STATUS</th></tr></thead><tbody>${attendees.map(a=>`<tr><td><b>${escapeHtml(a.name)}</b></td><td>${escapeHtml(a.email)}</td><td>${escapeHtml(a.event)}</td><td><span class="status Live">Registered</span></td></tr>`).join("")}</tbody></table></div>`}
 else if(page==="speakers"){box.innerHTML=`<div class="generic-list"><div class="mini-card"><div class="avatar">NV</div><h3>Dr. Neha Verma</h3><p>AI Research Lead · Tech Connect</p></div><div class="mini-card"><div class="avatar">AS</div><h3>Arjun Sinha</h3><p>Product Designer · Design Thinking</p></div><div class="mini-card"><div class="avatar">RK</div><h3>Rohan Kapoor</h3><p>Data Scientist · Future of Data</p></div></div>`}
 else if(page==="venues"){box.innerHTML=`<div class="generic-list"><div class="mini-card"><h3>Grand Convention Center</h3><p>Capacity: 500 · Lucknow</p><span class="status Upcoming">Booked Oct 28</span></div><div class="mini-card"><h3>Studio Hall, Block A</h3><p>Capacity: 100 · Campus</p><span class="status Upcoming">Booked Oct 24</span></div><div class="mini-card"><h3>The Atrium</h3><p>Capacity: 180 · Lucknow</p><span class="status Live">In use today</span></div></div>`}
 else if(page==="reports"){box.innerHTML=`<div class="generic-list"><div class="mini-card"><h3>Total events</h3><div class="mini-number">${events.length}</div><p>Events in this demo workspace</p></div><div class="mini-card"><h3>Registrations</h3><div class="mini-number">${attendees.length}</div><p>Sample attendee records</p></div><div class="mini-card"><h3>Capacity used</h3><div class="mini-number">${events.reduce((s,e)=>s+Number(e.attendees||0),0)}</div><p>Seats currently registered</p></div></div><p class="muted" style="margin-top:20px">Use “Export report” to download the current event list as CSV.</p>`}
 else {box.innerHTML=`<div class="generic-list"><div class="mini-card"><h3>Workspace profile</h3><p>EventFlow Demo Workspace</p><p>Admin: Ravi Yadav</p></div><div class="mini-card"><h3>Notifications</h3><p>In-app notifications are enabled for this demo.</p><button class="secondary-btn" id="toggleNotice">Toggle notification demo</button></div><div class="mini-card"><h3>Data storage</h3><p>Data is stored in this browser using localStorage. A production app needs a secure backend.</p></div></div>`;const b=$("#toggleNotice");if(b)b.onclick=()=>toast("Notification preferences updated (demo).")}
}
function exportCSV(){
 const rows=[["Event","Category","Date","Time","Venue","Attendees","Capacity","Status"],...events.map(e=>[e.name,e.category,e.date,e.time,e.venue,e.attendees,e.capacity,e.status])];
 const csv=rows.map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");
 const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="eventflow-report.csv";a.click();URL.revokeObjectURL(url);toast("CSV report downloaded.");
}
$("#exportBtn").addEventListener("click",exportCSV);
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#helpBtn").addEventListener("click",()=>toast("Help center: see README.md for setup and deployment."));
$("#notificationBtn").addEventListener("click",()=>toast("You're all caught up!"));
$("#activityBtn").addEventListener("click",()=>toast("Showing the latest 3 activity updates."));
$("#chartRange").addEventListener("change",()=>{if(window.revenueChart){const n=Number($("#chartRange").value);window.revenueChart.data.labels=["Apr","May","Jun","Jul","Aug","Sep","Oct"].slice(-n);window.revenueChart.data.datasets[0].data=[24,32,29,44,38,55,68].slice(-n);window.revenueChart.update();}});
function initCharts(){
 if(!window.Chart)return;
 const c=$("#revenueChart");if(c)window.revenueChart=new Chart(c,{type:"line",data:{labels:["Apr","May","Jun","Jul","Aug","Sep","Oct"],datasets:[{label:"Revenue (₹k)",data:[24,32,29,44,38,55,68],borderColor:"#7158e2",backgroundColor:"rgba(113,88,226,.10)",fill:true,tension:.42,pointRadius:3,pointHoverRadius:5,pointBackgroundColor:"#fff",pointBorderColor:"#7158e2",pointBorderWidth:2,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{backgroundColor:"#252940",padding:11,displayColors:false,callbacks:{label:c=>" ₹"+c.parsed.y+"k"}}},scales:{x:{grid:{display:false},border:{display:false},ticks:{color:"#a0a5b7",font:{size:10}}},y:{beginAtZero:true,grid:{color:"#f0f1f7",drawBorder:false},border:{display:false},ticks:{color:"#a0a5b7",font:{size:10},callback:v=>"₹"+v+"k"}}}}});
 const d=$("#categoryChart");if(d)new Chart(d,{type:"doughnut",data:{labels:["Conference","Workshop","Networking","Other"],datasets:[{data:[38,27,20,15],backgroundColor:["#7158e2","#4b8df8","#27b887","#f4a340"],borderWidth:0,hoverOffset:4}]},options:{responsive:true,maintainAspectRatio:false,cutout:"76%",plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`${c.label}: ${c.parsed}%`}}}}});
}
renderEvents();initCharts();
