# EventFlow — Event Management Dashboard

A responsive front-end demo dashboard built with HTML, CSS and JavaScript.

## Features
- Dashboard cards for events, attendees, revenue and attendance rate
- Revenue line chart and event category doughnut chart (Chart.js CDN)
- Upcoming events table with search and delete action
- Create event and add attendee dialogs
- Events, attendees, speakers, venues, reports and settings sections
- CSV report export
- Local browser persistence using `localStorage`
- Responsive sidebar/layout for mobile and desktop

## Run locally
1. Extract `event_management_dashboard.zip`.
2. Open the folder in VS Code.
3. Install the **Live Server** extension.
4. Right-click `index.html` → **Open with Live Server**.
   - Or open `index.html` directly in your browser (charts need internet for the Chart.js CDN).

## Free deployment with GitHub Pages
1. Sign in to GitHub and create a new public repository, e.g. `eventflow-dashboard`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for the published URL shown in the Pages section, usually `https://YOUR-USERNAME.github.io/eventflow-dashboard/`.

## Important demo limitations
- This project is a front-end prototype. Event/attendee data is saved only in the current browser using `localStorage`.
- The payment flow, real ticket QR validation, email/SMS, login, multi-user sync, and secure backend are **not connected**. Do not collect real payment or sensitive attendee data with this demo.
- For a production version, add a backend (e.g. Node.js/Express), database (PostgreSQL/MongoDB), authentication, and a payment provider's official checkout flow. Never store card details in front-end code.
